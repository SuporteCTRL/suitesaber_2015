<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<meta http-equiv="Expires" content="-1"/>
<meta http-equiv="pragma" content="no-cache"/>

<? include( $localPath['html'] . "/metainfo.html"); ?>

<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta name="generator" content="BVS-Site <?= VERSION ?>" />

<script type="text/javascript">var lang = '<?=$checked['lang']?>';</script>
<script type="text/javascript" src="<?=$def['DIRECTORY']?>js/functions.js"></script>
<script type="text/javascript" src="<?=$def['DIRECTORY']?>js/showHide.js"></script>
<script type="text/javascript" src="<?=$def['DIRECTORY']?>js/metasearch.js"></script>
<script type="text/javascript" src="<?=$def['DIRECTORY']?>js/jquery-1.3.1.min.js"></script>

<link rel="shortcut icon" href="<?=$def['DIRECTORY']?>favicon.ico"/>
<link rel="stylesheet" href="<?=$def['DIRECTORY']?>css/public/print.css" type="text/css" media="print"/>
<link rel="stylesheet" href="<?=$def['DIRECTORY']?>css/public/skins/<?=SKIN_NAME?>/style-<?=$checked['lang']?>.css" type="text/css" media="screen"/>