<?php
    // compatibilidade com vers�o 3.0 do BVS-Site
    header("Location: /admin/index.php");
?>
